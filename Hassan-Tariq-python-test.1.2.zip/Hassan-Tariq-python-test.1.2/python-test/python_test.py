import json
import random

def main(json_data):
    """
    Function responsible of reading and parsing the functional commands from the file
    """

    commands_dict = {
        'parse': [],
        'copy': [],
        'functional': [],
        'random': []
    }
    
    commands_dict['random'] = random.sample(json_data, 2)
    for row in json_data:
        row_function = row.get('function')
        if row_function in commands_dict.keys():
            commands_dict[row_function].append(row)
            functional_row = row.copy()
            functional_row['_counter'] = len(commands_dict[row_function])
            functional_row['_list'] = row_function
            commands_dict['functional'].append(functional_row)

    return commands_dict['parse'], commands_dict['copy'], commands_dict['functional'], commands_dict['random']



if __name__ == '__main__':
    with open('data.txt', 'r') as data_file:
        json_data = json.loads(data_file.read())
        parse_commands, copy_commands, functional_commands, random_commands = main(json_data)

    assert parse_commands == [{'function': 'parse', 'help': 'file help', 'value': 'file'}]
    assert copy_commands == [{'function': 'copy', 'help': 'copy help', 'value': 'file'}]
    assert functional_commands == [{'function': 'parse', 'help': 'file help', 'value': 'file', '_list': 'parse', '_counter': 1}, {'function': 'copy', 'help': 'copy help', 'value': 'file', '_list': 'copy', '_counter': 1}]
    assert len(random_commands) == 2

from unittest import TestCase
from python_test import main

class TestCommands(TestCase):

    def test_main_with_invalid_dict(self):
        invalid_dict = [
            {
                "function": None,
            },
            {
                "function": "parse",
                "help": "help"
            },
            {
                "function": "Other",
                "help": "help"
            }
        ]

        parse_commands = [{
                "function": "parse",
                "help": "help"
            }]

        assert main(invalid_dict) == (parse_commands, [], parse_commands, []) 
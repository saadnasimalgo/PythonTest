
from commands import Commands

def test_copy_commands():
    commands = Commands()
    copy_commands = commands.get_copy_commands()
    assert copy_commands == [{'function': 'copy', 'help': 'copy help', 'value': 'file'}]
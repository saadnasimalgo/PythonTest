import json, random

class Commands:

    @staticmethod
    def get_parse_commands():
        # NOTE: Get all the parse commands
        with open('input/data.txt', 'r') as file:
            data = json.loads(file.read())
        print(json.dumps(data))
        parse_commands = []
        for row in data:
            print("row",row)
            if 'function' in row and row['function'] == 'parse':
                parse_commands.append(row.copy())
        print(f"parse_commands: {parse_commands}")
        return parse_commands

    @staticmethod
    def get_copy_commands():
        # NOTE: Get all the copy commands
        with open('input/data.txt', 'r') as file:
            data = json.loads(file.read())
        copy_commands = []
        for row in data:
            if 'function' in row and row['function'] == 'copy':
                copy_commands.append(row.copy())
        print(f"copy_commands: {copy_commands}")
        return copy_commands

    def get_functional_commands(self):
        # NOTE: Put the two lists together and say which list it came from as well as the item number for that list
        copy_commands = self.get_copy_commands()
        parse_commands = self.get_parse_commands()

        functional_commands = []
        counter = 0
        for row in parse_commands:
            counter += 1
            new_row = row.copy()
            new_row['_list'] = 'parse'
            new_row['_counter'] = counter
            functional_commands.append(new_row)
        counter = 0
        for row in copy_commands:
            counter += 1
            new_row = row.copy()
            new_row['_list'] = 'copy'
            new_row['_counter'] = counter
            functional_commands.append(new_row)
        print(f"functional_commands: {functional_commands}")
        return functional_commands

    @staticmethod
    def get_random_sampling_of_data():
        # NOTE: Get random sampling of data
        random_commands = []
        with open('input/data.txt', 'r') as file:
            data = json.loads(file.read())
            random_commands = random.sample(data, 2)
        print(f"random_commands: {random_commands}")
        return random_commands

if __name__=="__main__":
    c = Commands()
    c.get_parse_commands()
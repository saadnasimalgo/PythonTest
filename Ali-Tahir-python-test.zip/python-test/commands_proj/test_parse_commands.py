
from commands import Commands

def test_parse_commands():
    commands = Commands()
    parse_commands = commands.get_parse_commands()
    assert parse_commands == [{'function': 'parse', 'help': 'file help', 'value': 'file'}]
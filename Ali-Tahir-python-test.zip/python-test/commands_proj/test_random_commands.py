
from commands import Commands

def test_random_commands():
    commands = Commands()
    random_commands = commands.get_random_sampling_of_data()
    assert len(random_commands) == 2